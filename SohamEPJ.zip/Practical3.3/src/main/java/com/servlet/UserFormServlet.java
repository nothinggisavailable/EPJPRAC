package com.servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/UserFormServlet")
public class UserFormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handle POST request (form submission)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get form parameters
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String age = request.getParameter("age");

        // Display data in a neat HTML table
        out.println("<html><head><title>User Details</title></head><body>");
        out.println("<h2>User Details Submitted</h2>");
        out.println("<table border='1' cellpadding='10'>");
        out.println("<tr><th>Field</th><th>Value</th></tr>");
        out.println("<tr><td>Name</td><td>" + name + "</td></tr>");
        out.println("<tr><td>Email</td><td>" + email + "</td></tr>");
        out.println("<tr><td>Age</td><td>" + age + "</td></tr>");
        out.println("</table>");
        out.println("<br><a href='userForm.html'>Go Back to Form</a>");
        out.println("</body></html>");
    }


// Handle GET request (redirect to form)
    
protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.sendRedirect("userForm.html");
    }
}
