package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Hardcoded credentials
    private final String USERNAME = "Soham";
    private final String PASSWORD = "2303051051137";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (PrintWriter out = response.getWriter()) {
            out.println("<!doctype html><html><head><meta charset='utf-8'><title>Login</title></head><body>");
            if (USERNAME.equals(username) && PASSWORD.equals(password)) {
                out.println("<h2>Login Successful!</h2>");
                out.println("<h2>Soham 2303051051137</h2>");
                out.println("<p>Welcome, " + username + "!</p>");
            } else {
                out.println("<h2>Login Failed!</h2>");
                out.println("<p>Invalid username or password.</p>");
                out.println("<a href='Login.html'>Try Again</a>");
            }
            out.println("</body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("Login.html");
    }
}