package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

@WebServlet("/RequestDetailsServlet")
public class RequestDetailsServlet extends HttpServlet {
private static final long serialVersionUID = 1L;

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();

out.println("<html><body>");
out.println("<h2>Request Details</h2>");

// Basic request info
out.println("<p><b>Method:</b> " + request.getMethod() + "</p>");
out.println("<p><b>Request URI:</b> " + request.getRequestURI() + "</p>");
out.println("<p><b>Protocol:</b> " + request.getProtocol() + "</p>");
out.println("<p><b>Remote Address:</b> " + request.getRemoteAddr() + "</p>");
out.println("<p><b>Remote Host:</b> " + request.getRemoteHost() + "</p>");

// Headers
out.println("<h3>Request Headers:</h3>");
Enumeration<String> headerNames = request.getHeaderNames();
while (headerNames.hasMoreElements()) {
String header = headerNames.nextElement();
out.println(header + " : " + request.getHeader(header) + "<br/>");
}
out.println("</body></html>");}}

