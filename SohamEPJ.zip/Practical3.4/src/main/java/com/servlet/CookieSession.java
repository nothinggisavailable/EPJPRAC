package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/CookieSessionServlet")
public class CookieSession extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int visitCount = 0;
		Cookie[] cookies = request.getCookies();
		
		if(cookies != null) {
			for(Cookie c:cookies) {
				if(c.getName().equals("visitCount")) {
					visitCount = Integer.parseInt(c.getValue());
				}
			}
		}
		visitCount++;
		Cookie newCookie = new Cookie("visitCount",String.valueOf(visitCount));
		newCookie.setMaxAge(60*60);
		response.addCookie(newCookie);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		out.println("<h1>Session Tracking using Cookies !</h1>");
		out.println("<h1>Soham Orivkar  2303051051137 !</h1>");
		out.println("<h3>Number of Visits using Cookies: " + visitCount + "</h3>");
	}}

