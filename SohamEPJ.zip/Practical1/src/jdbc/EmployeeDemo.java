package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class EmployeeDemo  {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/parul"; // schema = parul
        String user = "root";     // your MySQL username
        String password = "parul@8668"; // your MySQL password

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to DB
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println(" Connected to MySQL Database!");

            // Create statement
            Statement stmt = con.createStatement();

            // Query new table
            ResultSet rs = stmt.executeQuery("SELECT * FROM employee_new");

            // Print results
            System.out.println("Employee_New Table Data:");
            while (rs.next()) {
                System.out.println(rs.getInt("emp_id") + " | " +
                                   rs.getString("emp_name") + " | " +
                                   rs.getString("emp_email") + " | " +
                                   rs.getDouble("emp_salary"));
            }

            con.close();
         } catch (Exception e) {
            e.printStackTrace();
        }
    }}
