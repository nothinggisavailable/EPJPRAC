package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/httpSession_sessionTracking")
public class httpSession_sessionTracking extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true);
		Integer visitCount = (Integer) session.getAttribute("visitCount");
		
		if(visitCount == null) {
			visitCount = 1;
		}
		else {
			visitCount++;
		}
		session.setAttribute("visitCount", visitCount);
		// Set session timeout to 5 minutes (300 seconds)
				session.setMaxInactiveInterval(300);
		
		 String sessionId = session.getId(); 
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		out.println("<h1>Session Tracking using HttpSession !</h1>");
		out.println("<h1>Soham Orivkar 2303051051137 !</h1>");
		out.println("<h3>Number of Visits using HttpSession: " + visitCount + "</h3>");
		out.println("<h4>HttpSession ID: " + sessionId + "</h4>");
		
	} }
